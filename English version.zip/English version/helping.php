<!DOCTYPE html>
<html class="js wf-opensans-n4-active wf-opensans-n7-active wf-opensans-i4-active wf-robotoslab-n3-active wf-opensans-n3-active wf-robotoslab-n7-active wf-robotoslab-n4-active wf-permanentmarker-n4-active wf-merriweather-n7-active wf-active srcset supports backgroundblendmode cssfilters flexbox cssmask whatinput-types-initial whatinput-types-mouse translated-ltr" dir="ltr" itemscope="" itemtype="http://schema.org/WebPage" xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" version="XHTML+RDFa 1.0" xmlns:content="http://purl.org/rss/1.0/modules/content/" xmlns:dc="http://purl.org/dc/terms/" xmlns:foaf="http://xmlns.com/foaf/0.1/" xmlns:og="http://ogp.me/ns#" xmlns:rdfs="http://www.w3.org/2000/01/rdf-schema#" xmlns:sioc="http://rdfs.org/sioc/ns#" xmlns:sioct="http://rdfs.org/sioc/types#" xmlns:skos="http://www.w3.org/2004/02/skos/core#" xmlns:xsd="http://www.w3.org/2001/XMLSchema#" lang="en" data-whatinput="mouse" data-whatintent="mouse"><head profile="http://www.w3.org/1999/xhtml/vocab"><script type="text/javascript" src="https://bam.nr-data.net/1/c0f6715532?a=26862536&amp;v=1071.385e752&amp;to=blwEN0dTXBADAkxRVlcWMxFcHR0KDAVdQBdJURY%3D&amp;rst=59855&amp;ref=https://rotary.org/it&amp;ap=18&amp;be=664&amp;fe=59592&amp;dc=2786&amp;af=err,xhr,stn,ins&amp;perf=%7B%22timing%22:%7B%22of%22:1537898630498,%22n%22:0,%22r%22:9,%22re%22:377,%22f%22:377,%22dn%22:377,%22dne%22:377,%22c%22:377,%22ce%22:377,%22rq%22:379,%22rp%22:637,%22rpe%22:696,%22dl%22:641,%22di%22:2786,%22ds%22:2786,%22de%22:2849,%22dc%22:59591,%22l%22:59591,%22le%22:59625%7D,%22navigation%22:%7B%22rc%22:1%7D%7D&amp;at=QhsHQQ9JTx4%3D&amp;jsonp=NREUM.setToken"></script><script src="https://js-agent.newrelic.com/nr-1071.min.js"></script><script src="https://connect.facebook.net/signals/config/300232603793067?v=2.8.27&amp;r=stable" async=""></script><script async="" src="https://connect.facebook.net/en_US/fbevents.js"></script><script type="text/javascript" async="async" src="https://srotary.sc.omtrdc.net/id?d_visid_ver=1.5.6&amp;callback=s_c_il%5B0%5D._setAnalyticsFields&amp;mcorgid=6E43BF115751AA767F000101%40AdobeOrg&amp;mid=48970083527712211654327877771284033280"></script><script type="text/javascript" async="async" src="https://dpm.demdex.net/id?d_visid_ver=1.5.6&amp;d_rtbd=json&amp;d_ver=2&amp;d_orgid=6E43BF115751AA767F000101%40AdobeOrg&amp;d_nsid=0&amp;d_cb=s_c_il%5B0%5D._setMarketingCloudFields"></script>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8"><script async="" src="//www.google-analytics.com/analytics.js"></script><script src="https://ajax.googleapis.com/ajax/libs/webfont/1.6.16/webfont.js" type="text/javascript" async=""></script><script type="text/javascript">(window.NREUM||(NREUM={})).loader_config={xpid:"VQIDVFJaDRACUllUBQQEUA=="};window.NREUM||(NREUM={}),__nr_require=function(t,n,e){function r(e){if(!n[e]){var o=n[e]={exports:{}};t[e][0].call(o.exports,function(n){var o=t[e][1][n];return r(o||n)},o,o.exports)}return n[e].exports}if("function"==typeof __nr_require)return __nr_require;for(var o=0;o<e.length;o++)r(e[o]);return r}({1:[function(t,n,e){function r(t){try{s.console&&console.log(t)}catch(n){}}var o,i=t("ee"),a=t(15),s={};try{o=localStorage.getItem("__nr_flags").split(","),console&&"function"==typeof console.log&&(s.console=!0,o.indexOf("dev")!==-1&&(s.dev=!0),o.indexOf("nr_dev")!==-1&&(s.nrDev=!0))}catch(c){}s.nrDev&&i.on("internal-error",function(t){r(t.stack)}),s.dev&&i.on("fn-err",function(t,n,e){r(e.stack)}),s.dev&&(r("NR AGENT IN DEVELOPMENT MODE"),r("flags: "+a(s,function(t,n){return t}).join(", ")))},{}],2:[function(t,n,e){function r(t,n,e,r,s){try{p?p-=1:o(s||new UncaughtException(t,n,e),!0)}catch(f){try{i("ierr",[f,c.now(),!0])}catch(d){}}return"function"==typeof u&&u.apply(this,a(arguments))}function UncaughtException(t,n,e){this.message=t||"Uncaught error with no additional information",this.sourceURL=n,this.line=e}function o(t,n){var e=n?null:c.now();i("err",[t,e])}var i=t("handle"),a=t(16),s=t("ee"),c=t("loader"),f=t("gos"),u=window.onerror,d=!1,l="nr@seenError",p=0;c.features.err=!0,t(1),window.onerror=r;try{throw new Error}catch(h){"stack"in h&&(t(8),t(7),"addEventListener"in window&&t(5),c.xhrWrappable&&t(9),d=!0)}s.on("fn-start",function(t,n,e){d&&(p+=1)}),s.on("fn-err",function(t,n,e){d&&!e[l]&&(f(e,l,function(){return!0}),this.thrown=!0,o(e))}),s.on("fn-end",function(){d&&!this.thrown&&p>0&&(p-=1)}),s.on("internal-error",function(t){i("ierr",[t,c.now(),!0])})},{}],3:[function(t,n,e){t("loader").features.ins=!0},{}],4:[function(t,n,e){function r(t){}if(window.performance&&window.performance.timing&&window.performance.getEntriesByType){var o=t("ee"),i=t("handle"),a=t(8),s=t(7),c="learResourceTimings",f="addEventListener",u="resourcetimingbufferfull",d="bstResource",l="resource",p="-start",h="-end",m="fn"+p,w="fn"+h,v="bstTimer",y="pushState",g=t("loader");g.features.stn=!0,t(6);var b=NREUM.o.EV;o.on(m,function(t,n){var e=t[0];e instanceof b&&(this.bstStart=g.now())}),o.on(w,function(t,n){var e=t[0];e instanceof b&&i("bst",[e,n,this.bstStart,g.now()])}),a.on(m,function(t,n,e){this.bstStart=g.now(),this.bstType=e}),a.on(w,function(t,n){i(v,[n,this.bstStart,g.now(),this.bstType])}),s.on(m,function(){this.bstStart=g.now()}),s.on(w,function(t,n){i(v,[n,this.bstStart,g.now(),"requestAnimationFrame"])}),o.on(y+p,function(t){this.time=g.now(),this.startPath=location.pathname+location.hash}),o.on(y+h,function(t){i("bstHist",[location.pathname+location.hash,this.startPath,this.time])}),f in window.performance&&(window.performance["c"+c]?window.performance[f](u,function(t){i(d,[window.performance.getEntriesByType(l)]),window.performance["c"+c]()},!1):window.performance[f]("webkit"+u,function(t){i(d,[window.performance.getEntriesByType(l)]),window.performance["webkitC"+c]()},!1)),document[f]("scroll",r,{passive:!0}),document[f]("keypress",r,!1),document[f]("click",r,!1)}},{}],5:[function(t,n,e){function r(t){for(var n=t;n&&!n.hasOwnProperty(u);)n=Object.getPrototypeOf(n);n&&o(n)}function o(t){s.inPlace(t,[u,d],"-",i)}function i(t,n){return t[1]}var a=t("ee").get("events"),s=t(18)(a,!0),c=t("gos"),f=XMLHttpRequest,u="addEventListener",d="removeEventListener";n.exports=a,"getPrototypeOf"in Object?(r(document),r(window),r(f.prototype)):f.prototype.hasOwnProperty(u)&&(o(window),o(f.prototype)),a.on(u+"-start",function(t,n){var e=t[1],r=c(e,"nr@wrapped",function(){function t(){if("function"==typeof e.handleEvent)return e.handleEvent.apply(e,arguments)}var n={object:t,"function":e}[typeof e];return n?s(n,"fn-",null,n.name||"anonymous"):e});this.wrapped=t[1]=r}),a.on(d+"-start",function(t){t[1]=this.wrapped||t[1]})},{}],6:[function(t,n,e){var r=t("ee").get("history"),o=t(18)(r);n.exports=r,o.inPlace(window.history,["pushState","replaceState"],"-")},{}],7:[function(t,n,e){var r=t("ee").get("raf"),o=t(18)(r),i="equestAnimationFrame";n.exports=r,o.inPlace(window,["r"+i,"mozR"+i,"webkitR"+i,"msR"+i],"raf-"),r.on("raf-start",function(t){t[0]=o(t[0],"fn-")})},{}],8:[function(t,n,e){function r(t,n,e){t[0]=a(t[0],"fn-",null,e)}function o(t,n,e){this.method=e,this.timerDuration=isNaN(t[1])?0:+t[1],t[0]=a(t[0],"fn-",this,e)}var i=t("ee").get("timer"),a=t(18)(i),s="setTimeout",c="setInterval",f="clearTimeout",u="-start",d="-";n.exports=i,a.inPlace(window,[s,"setImmediate"],s+d),a.inPlace(window,[c],c+d),a.inPlace(window,[f,"clearImmediate"],f+d),i.on(c+u,r),i.on(s+u,o)},{}],9:[function(t,n,e){function r(t,n){d.inPlace(n,["onreadystatechange"],"fn-",s)}function o(){var t=this,n=u.context(t);t.readyState>3&&!n.resolved&&(n.resolved=!0,u.emit("xhr-resolved",[],t)),d.inPlace(t,y,"fn-",s)}function i(t){g.push(t),h&&(x?x.then(a):w?w(a):(E=-E,O.data=E))}function a(){for(var t=0;t<g.length;t++)r([],g[t]);g.length&&(g=[])}function s(t,n){return n}function c(t,n){for(var e in t)n[e]=t[e];return n}t(5);var f=t("ee"),u=f.get("xhr"),d=t(18)(u),l=NREUM.o,p=l.XHR,h=l.MO,m=l.PR,w=l.SI,v="readystatechange",y=["onload","onerror","onabort","onloadstart","onloadend","onprogress","ontimeout"],g=[];n.exports=u;var b=window.XMLHttpRequest=function(t){var n=new p(t);try{u.emit("new-xhr",[n],n),n.addEventListener(v,o,!1)}catch(e){try{u.emit("internal-error",[e])}catch(r){}}return n};if(c(p,b),b.prototype=p.prototype,d.inPlace(b.prototype,["open","send"],"-xhr-",s),u.on("send-xhr-start",function(t,n){r(t,n),i(n)}),u.on("open-xhr-start",r),h){var x=m&&m.resolve();if(!w&&!m){var E=1,O=document.createTextNode(E);new h(a).observe(O,{characterData:!0})}}else f.on("fn-end",function(t){t[0]&&t[0].type===v||a()})},{}],10:[function(t,n,e){function r(t){var n=this.params,e=this.metrics;if(!this.ended){this.ended=!0;for(var r=0;r<d;r++)t.removeEventListener(u[r],this.listener,!1);if(!n.aborted){if(e.duration=a.now()-this.startTime,4===t.readyState){n.status=t.status;var i=o(t,this.lastSize);if(i&&(e.rxSize=i),this.sameOrigin){var c=t.getResponseHeader("X-NewRelic-App-Data");c&&(n.cat=c.split(", ").pop())}}else n.status=0;e.cbTime=this.cbTime,f.emit("xhr-done",[t],t),s("xhr",[n,e,this.startTime])}}}function o(t,n){var e=t.responseType;if("json"===e&&null!==n)return n;var r="arraybuffer"===e||"blob"===e||"json"===e?t.response:t.responseText;return h(r)}function i(t,n){var e=c(n),r=t.params;r.host=e.hostname+":"+e.port,r.pathname=e.pathname,t.sameOrigin=e.sameOrigin}var a=t("loader");if(a.xhrWrappable){var s=t("handle"),c=t(11),f=t("ee"),u=["load","error","abort","timeout"],d=u.length,l=t("id"),p=t(14),h=t(13),m=window.XMLHttpRequest;a.features.xhr=!0,t(9),f.on("new-xhr",function(t){var n=this;n.totalCbs=0,n.called=0,n.cbTime=0,n.end=r,n.ended=!1,n.xhrGuids={},n.lastSize=null,p&&(p>34||p<10)||window.opera||t.addEventListener("progress",function(t){n.lastSize=t.loaded},!1)}),f.on("open-xhr-start",function(t){this.params={method:t[0]},i(this,t[1]),this.metrics={}}),f.on("open-xhr-end",function(t,n){"loader_config"in NREUM&&"xpid"in NREUM.loader_config&&this.sameOrigin&&n.setRequestHeader("X-NewRelic-ID",NREUM.loader_config.xpid)}),f.on("send-xhr-start",function(t,n){var e=this.metrics,r=t[0],o=this;if(e&&r){var i=h(r);i&&(e.txSize=i)}this.startTime=a.now(),this.listener=function(t){try{"abort"===t.type&&(o.params.aborted=!0),("load"!==t.type||o.called===o.totalCbs&&(o.onloadCalled||"function"!=typeof n.onload))&&o.end(n)}catch(e){try{f.emit("internal-error",[e])}catch(r){}}};for(var s=0;s<d;s++)n.addEventListener(u[s],this.listener,!1)}),f.on("xhr-cb-time",function(t,n,e){this.cbTime+=t,n?this.onloadCalled=!0:this.called+=1,this.called!==this.totalCbs||!this.onloadCalled&&"function"==typeof e.onload||this.end(e)}),f.on("xhr-load-added",function(t,n){var e=""+l(t)+!!n;this.xhrGuids&&!this.xhrGuids[e]&&(this.xhrGuids[e]=!0,this.totalCbs+=1)}),f.on("xhr-load-removed",function(t,n){var e=""+l(t)+!!n;this.xhrGuids&&this.xhrGuids[e]&&(delete this.xhrGuids[e],this.totalCbs-=1)}),f.on("addEventListener-end",function(t,n){n instanceof m&&"load"===t[0]&&f.emit("xhr-load-added",[t[1],t[2]],n)}),f.on("removeEventListener-end",function(t,n){n instanceof m&&"load"===t[0]&&f.emit("xhr-load-removed",[t[1],t[2]],n)}),f.on("fn-start",function(t,n,e){n instanceof m&&("onload"===e&&(this.onload=!0),("load"===(t[0]&&t[0].type)||this.onload)&&(this.xhrCbStart=a.now()))}),f.on("fn-end",function(t,n){this.xhrCbStart&&f.emit("xhr-cb-time",[a.now()-this.xhrCbStart,this.onload,n],n)})}},{}],11:[function(t,n,e){n.exports=function(t){var n=document.createElement("a"),e=window.location,r={};n.href=t,r.port=n.port;var o=n.href.split("://");!r.port&&o[1]&&(r.port=o[1].split("/")[0].split("@").pop().split(":")[1]),r.port&&"0"!==r.port||(r.port="https"===o[0]?"443":"80"),r.hostname=n.hostname||e.hostname,r.pathname=n.pathname,r.protocol=o[0],"/"!==r.pathname.charAt(0)&&(r.pathname="/"+r.pathname);var i=!n.protocol||":"===n.protocol||n.protocol===e.protocol,a=n.hostname===document.domain&&n.port===e.port;return r.sameOrigin=i&&(!n.hostname||a),r}},{}],12:[function(t,n,e){function r(){}function o(t,n,e){return function(){return i(t,[f.now()].concat(s(arguments)),n?null:this,e),n?void 0:this}}var i=t("handle"),a=t(15),s=t(16),c=t("ee").get("tracer"),f=t("loader"),u=NREUM;"undefined"==typeof window.newrelic&&(newrelic=u);var d=["setPageViewName","setCustomAttribute","setErrorHandler","finished","addToTrace","inlineHit","addRelease"],l="api-",p=l+"ixn-";a(d,function(t,n){u[n]=o(l+n,!0,"api")}),u.addPageAction=o(l+"addPageAction",!0),u.setCurrentRouteName=o(l+"routeName",!0),n.exports=newrelic,u.interaction=function(){return(new r).get()};var h=r.prototype={createTracer:function(t,n){var e={},r=this,o="function"==typeof n;return i(p+"tracer",[f.now(),t,e],r),function(){if(c.emit((o?"":"no-")+"fn-start",[f.now(),r,o],e),o)try{return n.apply(this,arguments)}catch(t){throw c.emit("fn-err",[arguments,this,t],e),t}finally{c.emit("fn-end",[f.now()],e)}}}};a("setName,setAttribute,save,ignore,onEnd,getContext,end,get".split(","),function(t,n){h[n]=o(p+n)}),newrelic.noticeError=function(t){"string"==typeof t&&(t=new Error(t)),i("err",[t,f.now()])}},{}],13:[function(t,n,e){n.exports=function(t){if("string"==typeof t&&t.length)return t.length;if("object"==typeof t){if("undefined"!=typeof ArrayBuffer&&t instanceof ArrayBuffer&&t.byteLength)return t.byteLength;if("undefined"!=typeof Blob&&t instanceof Blob&&t.size)return t.size;if(!("undefined"!=typeof FormData&&t instanceof FormData))try{return JSON.stringify(t).length}catch(n){return}}}},{}],14:[function(t,n,e){var r=0,o=navigator.userAgent.match(/Firefox[\/\s](\d+\.\d+)/);o&&(r=+o[1]),n.exports=r},{}],15:[function(t,n,e){function r(t,n){var e=[],r="",i=0;for(r in t)o.call(t,r)&&(e[i]=n(r,t[r]),i+=1);return e}var o=Object.prototype.hasOwnProperty;n.exports=r},{}],16:[function(t,n,e){function r(t,n,e){n||(n=0),"undefined"==typeof e&&(e=t?t.length:0);for(var r=-1,o=e-n||0,i=Array(o<0?0:o);++r<o;)i[r]=t[n+r];return i}n.exports=r},{}],17:[function(t,n,e){n.exports={exists:"undefined"!=typeof window.performance&&window.performance.timing&&"undefined"!=typeof window.performance.timing.navigationStart}},{}],18:[function(t,n,e){function r(t){return!(t&&t instanceof Function&&t.apply&&!t[a])}var o=t("ee"),i=t(16),a="nr@original",s=Object.prototype.hasOwnProperty,c=!1;n.exports=function(t,n){function e(t,n,e,o){function nrWrapper(){var r,a,s,c;try{a=this,r=i(arguments),s="function"==typeof e?e(r,a):e||{}}catch(f){l([f,"",[r,a,o],s])}u(n+"start",[r,a,o],s);try{return c=t.apply(a,r)}catch(d){throw u(n+"err",[r,a,d],s),d}finally{u(n+"end",[r,a,c],s)}}return r(t)?t:(n||(n=""),nrWrapper[a]=t,d(t,nrWrapper),nrWrapper)}function f(t,n,o,i){o||(o="");var a,s,c,f="-"===o.charAt(0);for(c=0;c<n.length;c++)s=n[c],a=t[s],r(a)||(t[s]=e(a,f?s+o:o,i,s))}function u(e,r,o){if(!c||n){var i=c;c=!0;try{t.emit(e,r,o,n)}catch(a){l([a,e,r,o])}c=i}}function d(t,n){if(Object.defineProperty&&Object.keys)try{var e=Object.keys(t);return e.forEach(function(e){Object.defineProperty(n,e,{get:function(){return t[e]},set:function(n){return t[e]=n,n}})}),n}catch(r){l([r])}for(var o in t)s.call(t,o)&&(n[o]=t[o]);return n}function l(n){try{t.emit("internal-error",n)}catch(e){}}return t||(t=o),e.inPlace=f,e.flag=a,e}},{}],ee:[function(t,n,e){function r(){}function o(t){function n(t){return t&&t instanceof r?t:t?c(t,s,i):i()}function e(e,r,o,i){if(!l.aborted||i){t&&t(e,r,o);for(var a=n(o),s=h(e),c=s.length,f=0;f<c;f++)s[f].apply(a,r);var d=u[y[e]];return d&&d.push([g,e,r,a]),a}}function p(t,n){v[t]=h(t).concat(n)}function h(t){return v[t]||[]}function m(t){return d[t]=d[t]||o(e)}function w(t,n){f(t,function(t,e){n=n||"feature",y[e]=n,n in u||(u[n]=[])})}var v={},y={},g={on:p,emit:e,get:m,listeners:h,context:n,buffer:w,abort:a,aborted:!1};return g}function i(){return new r}function a(){(u.api||u.feature)&&(l.aborted=!0,u=l.backlog={})}var s="nr@context",c=t("gos"),f=t(15),u={},d={},l=n.exports=o();l.backlog=u},{}],gos:[function(t,n,e){function r(t,n,e){if(o.call(t,n))return t[n];var r=e();if(Object.defineProperty&&Object.keys)try{return Object.defineProperty(t,n,{value:r,writable:!0,enumerable:!1}),r}catch(i){}return t[n]=r,r}var o=Object.prototype.hasOwnProperty;n.exports=r},{}],handle:[function(t,n,e){function r(t,n,e,r){o.buffer([t],r),o.emit(t,n,e)}var o=t("ee").get("handle");n.exports=r,r.ee=o},{}],id:[function(t,n,e){function r(t){var n=typeof t;return!t||"object"!==n&&"function"!==n?-1:t===window?0:a(t,i,function(){return o++})}var o=1,i="nr@id",a=t("gos");n.exports=r},{}],loader:[function(t,n,e){function r(){if(!x++){var t=b.info=NREUM.info,n=l.getElementsByTagName("script")[0];if(setTimeout(u.abort,3e4),!(t&&t.licenseKey&&t.applicationID&&n))return u.abort();f(y,function(n,e){t[n]||(t[n]=e)}),c("mark",["onload",a()+b.offset],null,"api");var e=l.createElement("script");e.src="https://"+t.agent,n.parentNode.insertBefore(e,n)}}function o(){"complete"===l.readyState&&i()}function i(){c("mark",["domContent",a()+b.offset],null,"api")}function a(){return E.exists&&performance.now?Math.round(performance.now()):(s=Math.max((new Date).getTime(),s))-b.offset}var s=(new Date).getTime(),c=t("handle"),f=t(15),u=t("ee"),d=window,l=d.document,p="addEventListener",h="attachEvent",m=d.XMLHttpRequest,w=m&&m.prototype;NREUM.o={ST:setTimeout,SI:d.setImmediate,CT:clearTimeout,XHR:m,REQ:d.Request,EV:d.Event,PR:d.Promise,MO:d.MutationObserver};var v=""+location,y={beacon:"bam.nr-data.net",errorBeacon:"bam.nr-data.net",agent:"js-agent.newrelic.com/nr-1071.min.js"},g=m&&w&&w[p]&&!/CriOS/.test(navigator.userAgent),b=n.exports={offset:s,now:a,origin:v,features:{},xhrWrappable:g};t(12),l[p]?(l[p]("DOMContentLoaded",i,!1),d[p]("load",r,!1)):(l[h]("onreadystatechange",o),d[h]("onload",r)),c("mark",["firstbyte",s],null,"api");var x=0,E=t(17)},{}]},{},["loader",2,10,4,3]);</script>
<meta property="og:image" content="https://rotary.org/sites/all/themes/rotary_rotaryorg/images/home/AmbientWebDemo,w_544.jpg">
<meta property="og:title" content="Helping | Interact Zagreb-Zrinjevac">
<meta property="og:url" content="https://rotary.org/it">
<meta property="twitter:title" content="Home | Interact Zagreb-Zrinjevac">
<meta property="twitter:site" content="@rotary">
<meta name="Generator" content="Drupal 7 (http://drupal.org)">
<link rel="alternate" type="application/rss+xml" title="Rotary.org RSS" href="https://rotary.org/it/rss.xml">
<meta property="twitter:card" content="summary_large_image">
<meta property="twitter:image" content="https://rotary.org/sites/all/themes/rotary_rotaryorg/images/home/AmbientWebDemo,w_544.jpg">

    <script>(function(H){H.className=H.className.replace(/\bno-js\b/,'js')})(document.documentElement)</script>

<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta itemprop="name" content="Interact Zagreb-Zrinjevac">

  <title>Home | Interact Zagreb-Zrinjevac</title>


<meta name="msapplication-TileColor" content="#0033a0">
<meta name="msapplication-TileImage" content="/sites/all/themes/rotary_rotaryorg/images/favicons/mstile-144x144.png">
<meta name="theme-color" content="#0033a0">

<!--[if IE 9]>
<script src="https://rotary.org/sites/all/themes/rotary_rotaryorg/scripts/polyfills-ie9.js"></script>
<![endif]-->

<script>window.pubSub=function(){var e={},t=e.hasOwnProperty;return{subscribe:function(n,o){t.call(e,n)||(e[n]=[]);var a=e[n].push(o)-1;return{remove:function(){delete e[n][a]}}},publish:function(n,o){if(t.call(e,n))for(var a=0,i=e[n].length;i>a;a++)e[n][a](void 0!==o?o:{})}}}(),function(){var e=document.documentElement.lang;if(e&&"ko"!==e&&"ja"!==e){sessionStorage["fonts-loaded"]&&document.documentElement.classList.add("wf-active"),WebFontConfig={active:function(){sessionStorage["fonts-loaded"]=!0,window.pubSub.publish("fontsLoaded")},google:{families:["Open+Sans:300,400,700,400italic:latin","Roboto+Slab:300,400,700","Permanent Marker:400","Merriweather:700"]},timeout:2e3};var t=document.createElement("script");t.src="https://ajax.googleapis.com/ajax/libs/webfont/1.6.16/webfont.js",t.type="text/javascript",t.async="true";var n=document.getElementsByTagName("script")[0];n.parentNode.insertBefore(t,n)}}();</script>

<style type="text/css" media="all">
@import url("https://rotary.org/modules/system/system.base.css?pewoxq");
@import url("https://rotary.org/modules/system/system.menus.css?pewoxq");
@import url("https://rotary.org/modules/system/system.messages.css?pewoxq");
@import url("https://rotary.org/modules/system/system.theme.css?pewoxq");
</style>
<style type="text/css" media="all">
@import url("https://rotary.org/sites/all/modules/contrib/date/date_api/date.css?pewoxq");
@import url("https://rotary.org/modules/field/theme/field.css?pewoxq");
@import url("https://rotary.org/sites/all/modules/contrib/google_appliance/theme/google_appliance.css?pewoxq");
@import url("https://rotary.org/modules/node/node.css?pewoxq");
@import url("https://rotary.org/sites/all/modules/custom/rotary_browser_alert/assets/css/rotary_browser_alert.css?pewoxq");
@import url("https://rotary.org/modules/user/user.css?pewoxq");
@import url("https://rotary.org/sites/all/modules/contrib/views/css/views.css?pewoxq");
</style>
<style type="text/css" media="all">
@import url("https://rotary.org/sites/default/modules/contrib/ctools/css/ctools.css?pewoxq");
</style>
<style type="text/css" media="all">
@import url("https://rotary.org/sites/all/themes/rotary_rotaryorg/styles/index.css?pewoxq");
</style>
<link rel="stylesheet" type="text/css" href="contact.css">
<script src="contact.js"></script>
<?php include('C:/xampp/htdocs/form_process.php'); ?>

<style>
form {

  margin: 0 auto;
  width: 400px;

  padding: 1em;
  border: 1px solid #CCC;
  border-radius: 1em;
}

form div + div {
  margin-top: 1em;
}

label {

  display: inline-block;
  width: 90px;
  text-align: right;
}

input, textarea {

  font: 1em sans-serif;


  width: 300px;
  box-sizing: border-box;


  border: 1px solid #999;
}

input:focus, textarea:focus {

  border-color: #000;
}

textarea {
/
  vertical-align: top;


  height: 5em;
}

.button {

  padding-left: 90px;
}

button {

  margin-left: .5em;
}
</style>

<script type="text/javascript">
<!--//--><![CDATA[//><!--
(function(i,s,o,g,r,a,m){i["GoogleAnalyticsObject"]=r;i[r]=i[r]||function(){(i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)})(window,document,"script","//www.google-analytics.com/analytics.js","ga");ga("create", "UA-37277988-1", {"cookieDomain":"auto"});ga("set", "anonymizeIp", true);ga("send", "pageview");
//--><!]]>
</script>

<!--Start Interact Front Page-->
<!-- Start Interact Header-->
    <header class="site-header">
    <div class="site-header-container" data-nav-header="">


      <p class="site-header-logo">
                <a href="/it" title="Home" rel="home" id="logo">
          <img src="/Int Logo.png" alt="Interact" height="100%" width="100%">
        </a>
      </p>

            <button aria-controls="site-navigation" class="site-nav-toggle-mobile" data-module="nav-toggle" data-features="setToWindowHeight" data-toggle="navigation" aria-expanded="false">
  <span class="site-nav-toggle-mobile-icon"></span>
  <span class="a11y-sr-only"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Main</font></font></span><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"> Menu
</font></font></button>

<button aria-controls="site-search" class="site-nav-toggle-search" data-module="nav-toggle" data-features="focusInput" data-toggle="search" aria-expanded="false">
  <span class="site-nav-toggle-search-icon"></span><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">
  Search for
</font></font></button>
    </div><!-- site-header-container -->

    <div class="site-nav-container" id="site-navigation">
      <div class="site-nav-utility">
        <div class="site-nav-utility-container">

                    <ul class="site-nav-utility-links -large">

  <li>
    <a href="https://my.rotary.org/it/search/club-finder">
      <svg focusable="false" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="8.035" height="11" viewBox="0 0 8.035 11"><defs><path id="a" d="M0 0h8.035v11H0z"></path></defs><clipPath id="b"><use xlink:href="#a" overflow="visible"></use></clipPath><path clip-path="url(#b)" d="M7.818 4.017c0 .525-.106 1.024-.3 1.48-.576 1.363-3.5 5.147-3.5 5.147S1.092 6.86.514 5.497c-.192-.455-.298-.955-.298-1.48 0-2.1 1.7-3.8 3.8-3.8s3.8 1.702 3.8 3.8m-3.8-1.885c-.938 0-1.697.76-1.697 1.697s.76 1.697 1.697 1.697 1.697-.76 1.697-1.698-.76-1.698-1.697-1.698"></path><g><defs><path id="c" d="M0 0h8.035v11H0z"></path></defs><clipPath id="d"><use xlink:href="#c" overflow="visible"></use></clipPath><path clip-path="url(#d)" d="M4.017 11l-.172-.222c-.12-.156-2.95-3.822-3.53-5.196C.105 5.086 0 4.56 0 4.017S.106 2.95.316 2.453c.203-.48.492-.908.86-1.277.37-.37.8-.66 1.278-.86C2.95.105 3.474 0 4.017 0 4.56 0 5.085.106 5.58.316c.48.202.91.49 1.278.86.37.37.66.8.86 1.278.21.496.317 1.022.317 1.564S7.93 5.086 7.72 5.58c-.582 1.375-3.41 5.042-3.53 5.197L4.016 11zm0-10.566c-.957 0-1.857.373-2.534 1.05C.807 2.16.433 3.06.433 4.017c0 .484.096.953.282 1.395.48 1.134 2.67 4.044 3.302 4.875.634-.83 2.823-3.74 3.303-4.875.187-.442.28-.91.28-1.395 0-.957-.372-1.857-1.048-2.534C5.874.807 4.974.433 4.017.433m0 5.31c-1.056 0-1.915-.86-1.915-1.915s.86-1.915 1.915-1.915 1.915.86 1.915 1.915-.86 1.915-1.915 1.915m0-3.395c-.816 0-1.48.664-1.48 1.48s.664 1.48 1.48 1.48 1.48-.665 1.48-1.48-.664-1.48-1.48-1.48"></path></g></svg><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">
      Find Club
    </font></font></a>
  </li>
</ul>

<label class="a11y-sr-only" for="search"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Search Rotary.org</font></font></label><input type="hidden" name="form_build_id" value="form-udA4pW5l0baK1VdDFR6-y90JhYL6gwAetr9og8n9YlQ">
<input type="hidden" name="form_id" value="rotary_basic_gsa_integration_block_form">
</div></form></div>


      </div>
    </div>
        <nav class="site-nav" data-nav="" aria-label="main navigation">
  <ul class="site-nav-list"><li data-module="nav-group" class="site-nav-item" data-is="close"><p class="site-nav-item-heading"><a href="/it/about-rotary" data-nav-headinglink="" aria-expanded="false"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">About us </font></font><span class="site-nav-a11y-helper"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">(down arrow opens sub-menu)&gt;</font></font></span></a></p><ul class="site-nav-sublist" data-nav-sublist="" data-is="close" data-columns="0">
<li><a href="history.html" data-nav-headinglink="" tabindex="-1"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">History</font></font></a></li>
<li><a href="membership.html" data-nav-headinglink="" tabindex="-1"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Membership</font></font></a></li>
</ul></li>
<li data-module="nav-group" class="site-nav-item" data-is="close"><p class="site-nav-item-heading"><a href="/it/get-involved" data-nav-headinglink="" aria-expanded="false"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Engage with us </font></font><span class="site-nav-a11y-helper"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">(down arrow opens sub-menu)&gt;</font></font></span></a></p><ul class="site-nav-sublist" data-nav-sublist="" data-is="close" data-columns="0">
<li><a href="Rotary.html" data-nav-headinglink="" tabindex="-1"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Rotary club</font></font></a></li>
<li><a href="Interact.html" data-nav-headinglink="" tabindex="-1"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Interact club</font></font></a></li>
<li><a href="Rotaract.html" data-nav-headinglink="" tabindex="-1"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Rotaract club</font></font></a></li>
</ul></li>

<li data-module="nav-group" class="site-nav-item" data-is="close"><p class="site-nav-item-heading"><a href="/it/our-causes" data-nav-headinglink="" aria-expanded="false"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Causes and Administration </font></font><span class="site-nav-a11y-helper"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">(down arrow opens sub-menu)&gt;</font></font></span></a></p><ul class="site-nav-sublist" data-nav-sublist="" data-is="close" data-columns="0">
<li><a href="helping.php" data-nav-headinglink="" tabindex="-1"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Helping society</font></font></a></li>
<li><a href="solutions.html" data-nav-headinglink="" tabindex="-1"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">President</font></font></a></li>
<li><a href="education.html" data-nav-headinglink="" tabindex="-1"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Education</font></font></a></li>
<li><a href="solving.html" data-nav-headinglink="" tabindex="-1"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Goals</font></font></a></li>
</ul></li>
<li data-module="nav-group" class="site-nav-item" data-is="close"><p class="site-nav-item-heading"><a href="/it/our-programs" data-nav-headinglink="" aria-expanded="false"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Activities </font></font><span class="site-nav-a11y-helper"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">(down arrow opens sub-menu)&gt;</font></font></span></a></p><ul class="site-nav-sublist" data-nav-sublist="" data-is="close" data-columns="0">
<li><a href="RYLA.html" data-nav-headinglink="" tabindex="-1"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">RYLA</font></font></a></li>
<li><a href="noa.html" data-nav-headinglink="" tabindex="-1"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Noa's Arc</font></font></a></li>
</ul></li>

<li data-module="nav-group" class="site-nav-item" data-is="close"><p class="site-nav-item-heading"><a href="/it/Members" title="" data-nav-headinglink="" aria-expanded="false"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Members </font></font><span class="site-nav-a11y-helper"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">(down arrow opens sub-menu)&gt;</font></font></span></a></p><ul class="site-nav-sublist" data-nav-sublist="" data-is="close" data-columns="0">
<li><a href="Login.html" title="" data-nav-headinglink="" tabindex="-1"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Login</font></font></a></li>
</ul></li>
</ul></nav>


        <ul class="site-nav-utility-links -small">

  <li>
    <a href="Interact-finder.html">
      <svg focusable="false" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="8.035" height="11" viewBox="0 0 8.035 11"><defs><path id="a" d="M0 0h8.035v11H0z"></path></defs><clipPath id="b"><use xlink:href="#a" overflow="visible"></use></clipPath><path clip-path="url(#b)" d="M7.818 4.017c0 .525-.106 1.024-.3 1.48-.576 1.363-3.5 5.147-3.5 5.147S1.092 6.86.514 5.497c-.192-.455-.298-.955-.298-1.48 0-2.1 1.7-3.8 3.8-3.8s3.8 1.702 3.8 3.8m-3.8-1.885c-.938 0-1.697.76-1.697 1.697s.76 1.697 1.697 1.697 1.697-.76 1.697-1.698-.76-1.698-1.697-1.698"></path><g><defs><path id="c" d="M0 0h8.035v11H0z"></path></defs><clipPath id="d"><use xlink:href="#c" overflow="visible"></use></clipPath><path clip-path="url(#d)" d="M4.017 11l-.172-.222c-.12-.156-2.95-3.822-3.53-5.196C.105 5.086 0 4.56 0 4.017S.106 2.95.316 2.453c.203-.48.492-.908.86-1.277.37-.37.8-.66 1.278-.86C2.95.105 3.474 0 4.017 0 4.56 0 5.085.106 5.58.316c.48.202.91.49 1.278.86.37.37.66.8.86 1.278.21.496.317 1.022.317 1.564S7.93 5.086 7.72 5.58c-.582 1.375-3.41 5.042-3.53 5.197L4.016 11zm0-10.566c-.957 0-1.857.373-2.534 1.05C.807 2.16.433 3.06.433 4.017c0 .484.096.953.282 1.395.48 1.134 2.67 4.044 3.302 4.875.634-.83 2.823-3.74 3.303-4.875.187-.442.28-.91.28-1.395 0-.957-.372-1.857-1.048-2.534C5.874.807 4.974.433 4.017.433m0 5.31c-1.056 0-1.915-.86-1.915-1.915s.86-1.915 1.915-1.915 1.915.86 1.915 1.915-.86 1.915-1.915 1.915m0-3.395c-.816 0-1.48.664-1.48 1.48s.664 1.48 1.48 1.48 1.48-.665 1.48-1.48-.664-1.48-1.48-1.48"></path></g></svg><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">
      hrvatski
    </font></font></a>
  </li>
</ul>
</div>
</header>
<!-- End Rotary Header-->

<main class="site-main" id="main" tabindex="-1">


  <div class="contact container shadow" id="contact_form" action="helping.php">
  <div class="contact row header">
    <h2>CONTACT</h2>
    <h3>Request information or help!</h3>
    <div id="contact_results"></div>
  </div>
  <div class="contact row body" id="contact_body">
    <div class="contact-elements">
      <ul>
        <li>
          <p class="left">
            <label for="name">name</label>
            <input type="text" name="name" id="name" required="true" class="input-field" placeholder="Jane Doe" />
          </p>
          <p class="pull-right">
            <label for="phone2">phone</label>
            <input type="text" name="phone2" maxlength="15" class="tel-number-field long" placeholder="123 456 7890" />
          </p>
        </li>

          <li>
            <p class="left">
              <label for="email">email</label>
              <input type="text" name="email" id="email" required="true" class="input-field" placeholder="jane.doe@gmail.com" />
            </p>
          </li>


        <li>
          <div class="contact divider"></div>
        </li>
        <li>
          <label for="message">enquiry</label>
          <textarea cols="46" rows="8" name="message" id="message" class="textarea-field" required="true"></textarea>
        </li>
      </ul>
    </div>
    <div class="center-btn" style="position:relevant; height:5vh;">
      <li>
        <input id="submit_btn" class="btn btn-submit" type="submit" value="Submit" />
      </li>
    </div>
  </div>
</div>
</!---contact-form--->












</main>
<!-- Start Rotary Footer -->
<footer class="site-footer" aria-label="site footer">
  <div class="layout-container -padding-reduced u-text-centered u-container">
  <!-- start block.tpl.twig template -->
  <ul class="site-footer-nav"><li class="site-footer-nav-item"><a href="Interact.html">About Interact</a></li><li class="site-footer-nav-item"><a href="membership.html">Members</a></li><li class="site-footer-nav-item"><a href="helping.html">Helping</a></li><li class="site-footer-nav-item"><a href="Rotary.html">Rotary</a></li><li class="site-footer-nav-item"><a href="Rotaract.html">Rotaract</a></li><li class="site-footer-nav-item"><a href="RYLA.html" title="">RYLA</a></li><li class="site-footer-nav-item"><a href="indexhrv.html">hrv</a></li></ul>
<!-- end block.tpl.twig template --><!-- start block.tpl.twig template -->

<!-- end block.tpl.twig template --><!-- start block.tpl.twig template -->

<ul class="site-footer-social">
            <li>
        <a href="https://www.twitter.com/interact-zagreb-zrinjevac">
          <img alt="twitter" src="/twitter.png">
          <span class="a11y-sr-only">Twitter</span>
        </a>
      </li>
                <li>
        <a href="https://www.facebook.com/interact-zagreb-zrinjevac">
          <img alt="Facebook" src="/face.png">
          <span class="a11y-sr-only">Facebook</span>
        </a>
      </li>

                <li>
        <a href="https://www.instagram.com/interactzagrebzrinjevac/">
          <img alt="instagram" src="/instagram.png">
          <span class="a11y-sr-only">Instagram</span>
        </a>
      </li>
                <li>
        <a href="https://www.linkedin.com/company/interact-zagreb-zrinjevac">
          <img alt="linkedin" src="/link.png">
          <span class="a11y-sr-only">Linkedin</span>
        </a>
      </li>
            </ul>


<!-- end block.tpl.twig template --><!-- start block.tpl.twig template -->
<p class="site-footer-legal"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">
  © 2018 Interact Zagreb-Zrinjevac. </font><font style="vertical-align: inherit;">All rights reserved.
  </font></font><a href="privacy.html"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Privacy </font></font></a>
  <a href="conditions.html"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Conditions of use</font></font></a>
</p>
</footer>
<!-- End Rotary Footer -->

<!--End Rotary Front Page-->
      <script type="text/javascript" src="https://rotary.org/sites/all/themes/rotary_rotaryorg/scripts/index.js?pewoxq"></script>
<script type="text/javascript" src="https://rotary.org/sites/all/themes/rotary_rotaryorg/scripts/home.js?pewoxq"></script>


<div class="goog-te-spinner-pos"><div class="goog-te-spinner-animation"><svg xmlns="http://www.w3.org/2000/svg" class="goog-te-spinner" width="96px" height="96px" viewBox="0 0 66 66"><circle class="goog-te-spinner-path" fill="none" stroke-width="6" stroke-linecap="round" cx="33" cy="33" r="30"></circle></svg></div></div></body><div class="a11y-focuser"></div></html>
